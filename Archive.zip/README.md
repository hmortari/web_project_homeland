# Homeland Project

(web_project_homeland)

Esse projeto foi desenvolvido durante o Sprint 5 do Bootcamp de Web Development da TripleTen. Consiste em construir uma landing page responsiva (1280-320) utilizando HTML 5, CSS e Figma.

- HTML5 - Marcação de keywords impulsionando resultados de SEO e Textos Alternativos melhorarando a acessibilidade de leitores.

- CSS3 - Flexbox + Grid Layout, Media Querys - Tamanho e tipo de aparelho, Font-face, Import e Normalize.

- BEM - Estrutura modular seguindo BEM Flat.
  Fonte hospedada localmente com Fall Back, Imagens otimizadas

https://hmortari.github.io/web_project_homeland/
